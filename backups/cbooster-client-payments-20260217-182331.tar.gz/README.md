# Credit Booster Client Payments

Мини-приложение для учёта платежей клиентов:
- таблица со всеми полями по клиентам;
- добавление нового клиента через форму;
- поиск по `Client name` и `Company Name`;
- хранение данных в `localStorage` браузера.

## Запуск

Откройте файл `/Users/ramisyaparov/Desktop/Project/CBooster Client Payments/index.html` в браузере.

Если хотите запустить через локальный сервер:

```bash
cd "/Users/ramisyaparov/Desktop/Project/CBooster Client Payments"
python3 -m http.server 8080
```

После запуска откройте: `http://localhost:8080`
